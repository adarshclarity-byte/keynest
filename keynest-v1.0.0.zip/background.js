import {
  deriveKey, encryptString, decryptString,
  keyToRawB64, rawB64ToKey, randomSalt, bufToB64, b64ToBuf,
} from './lib/crypto.js';
import { generatePassword } from './lib/passwordGen.js';

const DEFAULT_AUTO_LOCK_MINUTES = 10;
const USER_ALARM = 'auto-lock-user';
const ADMIN_ALARM = 'auto-lock-admin';
const APP_ALARM = 'auto-lock-app';
const PENDING_SAVE_TTL_MS = 5 * 60 * 1000;

const SCOPE_USER = 'user';
const SCOPE_ADMIN = 'admin';

// ---------- storage helpers ----------

function vaultKey(scope) {
  return scope === SCOPE_ADMIN ? 'adminVault' : 'userVault';
}
function sessionKeyName(scope) {
  return scope === SCOPE_ADMIN ? 'adminKeyB64' : 'userKeyB64';
}
function alarmName(scope) {
  return scope === SCOPE_ADMIN ? ADMIN_ALARM : USER_ALARM;
}

async function loadVaultBlob(scope) {
  const key = vaultKey(scope);
  const obj = await chrome.storage.local.get(key);
  return obj[key] || null;
}
async function saveVaultBlob(scope, blob) {
  await chrome.storage.local.set({ [vaultKey(scope)]: blob });
}

async function getSessionKey(scope) {
  const name = sessionKeyName(scope);
  const obj = await chrome.storage.session.get(name);
  if (!obj[name]) return null;
  return rawB64ToKey(obj[name]);
}
async function setSessionKey(scope, cryptoKey) {
  const b64 = await keyToRawB64(cryptoKey);
  await chrome.storage.session.set({ [sessionKeyName(scope)]: b64 });
}
async function clearSessionKey(scope) {
  await chrome.storage.session.remove(sessionKeyName(scope));
}

// Persistent (device-bound) admin key — lets admin entries autofill without
// re-prompting the user for the admin password on every autofill. Stored in
// chrome.storage.local; not exposed to any UI, never included in exports.
async function getPersistentAdminKey() {
  const { adminAutoKeyB64 } = await chrome.storage.local.get('adminAutoKeyB64');
  if (!adminAutoKeyB64) return null;
  return rawB64ToKey(adminAutoKeyB64);
}
async function setPersistentAdminKey(cryptoKey) {
  const b64 = await keyToRawB64(cryptoKey);
  await chrome.storage.local.set({ adminAutoKeyB64: b64 });
}
async function clearPersistentAdminKey() {
  await chrome.storage.local.remove('adminAutoKeyB64');
}

// Effective admin key for background-only operations: session key first
// (admin actively unlocked), otherwise the persistent device key (silent
// autofill). Never returned to popup/content.
async function getEffectiveAdminKey() {
  const s = await getSessionKey(SCOPE_ADMIN);
  if (s) return s;
  return getPersistentAdminKey();
}

async function getSettings() {
  const { settings } = await chrome.storage.local.get('settings');
  return { autoLockMinutes: DEFAULT_AUTO_LOCK_MINUTES, ...(settings || {}) };
}
async function saveSettings(settings) {
  await chrome.storage.local.set({ settings });
}

async function resetLockAlarm(scope) {
  const { autoLockMinutes } = await getSettings();
  const name = alarmName(scope);
  await chrome.alarms.clear(name);
  if (autoLockMinutes > 0) {
    await chrome.alarms.create(name, { delayInMinutes: autoLockMinutes });
  }
}

async function resetAppAlarm() {
  const { autoLockMinutes } = await getSettings();
  await chrome.alarms.clear(APP_ALARM);
  if (autoLockMinutes > 0) {
    await chrome.alarms.create(APP_ALARM, { delayInMinutes: autoLockMinutes });
  }
}

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === APP_ALARM) {
    // Idle timeout on the home-screen session — lock everything.
    await chrome.storage.session.remove('appUnlocked');
    await clearSessionKey(SCOPE_USER);
    await clearSessionKey(SCOPE_ADMIN);
    await updateBadge();
  } else if (alarm.name === USER_ALARM) {
    await clearSessionKey(SCOPE_USER);
    await updateBadge();
  } else if (alarm.name === ADMIN_ALARM) {
    await clearSessionKey(SCOPE_ADMIN);
  }
});

async function updateBadge() {
  try {
    const userLocked = !(await getSessionKey(SCOPE_USER));
    await chrome.action.setBadgeText({ text: userLocked ? 'L' : '' });
    await chrome.action.setBadgeBackgroundColor({ color: userLocked ? '#7c8394' : '#00000000' });
    await chrome.action.setBadgeTextColor({ color: '#ffffff' });
    await chrome.action.setTitle({ title: userLocked ? 'KeyNest — locked' : 'KeyNest' });
  } catch (e) { /* ignore */ }
}

// ---------- vault crypto ----------

async function decryptVaultPlaintext(scope, keyOverride) {
  const key = keyOverride || (scope === SCOPE_ADMIN ? await getEffectiveAdminKey() : await getSessionKey(scope));
  if (!key) throw new Error('LOCKED');
  const blob = await loadVaultBlob(scope);
  if (!blob) return { version: 1, entries: [] };
  const json = await decryptString(blob.iv, blob.ciphertext, key);
  return JSON.parse(json);
}

async function encryptAndSaveVault(scope, vaultObj, keyOverride) {
  const key = keyOverride || (scope === SCOPE_ADMIN ? await getEffectiveAdminKey() : await getSessionKey(scope));
  if (!key) throw new Error('LOCKED');
  const blob = await loadVaultBlob(scope);
  const salt = blob ? blob.salt : bufToB64(randomSalt());
  const { iv, ciphertext } = await encryptString(JSON.stringify(vaultObj), key);
  await saveVaultBlob(scope, { version: 1, salt, iv, ciphertext });
}

// ---------- URL helpers ----------

function normalizeOrigin(input) {
  if (!input) return '';
  try {
    if (input.includes('://')) return new URL(input).hostname.toLowerCase();
    return String(input).toLowerCase();
  } catch {
    return String(input).toLowerCase();
  }
}

function hostsMatch(a, b) {
  a = normalizeOrigin(a);
  b = normalizeOrigin(b);
  if (!a || !b) return false;
  if (a === b) return true;
  return a.endsWith('.' + b) || b.endsWith('.' + a);
}

// ---------- One-shot migration from old sync.vault ----------

async function migrateIfNeeded() {
  const { userVault, adminVault, migratedV2 } = await chrome.storage.local.get(['userVault', 'adminVault', 'migratedV2']);
  if (migratedV2) return;
  if (!userVault) {
    try {
      const legacy = await chrome.storage.sync.get('vault');
      if (legacy?.vault && legacy.vault.ciphertext) {
        await chrome.storage.local.set({ userVault: legacy.vault });
      }
    } catch (e) { /* ignore */ }
    try {
      const oldSettings = (await chrome.storage.sync.get('settings')).settings;
      if (oldSettings) await chrome.storage.local.set({ settings: oldSettings });
    } catch (e) { /* ignore */ }
  }
  await chrome.storage.local.set({ migratedV2: true });
}

// ---------- handlers ----------

const handlers = {
  async CHECK_STATE() {
    await migrateIfNeeded();
    const userBlob = await loadVaultBlob(SCOPE_USER);
    const adminBlob = await loadVaultBlob(SCOPE_ADMIN);
    const userKey = await getSessionKey(SCOPE_USER);
    const adminSess = await getSessionKey(SCOPE_ADMIN);
    const { appUnlocked } = await chrome.storage.session.get('appUnlocked');
    return {
      initialized: !!userBlob,
      adminInitialized: !!adminBlob,
      appUnlocked: !!appUnlocked,
      userUnlocked: !!userKey,
      adminUnlocked: !!adminSess,
      // Legacy shape kept so older code paths don't crash mid-migration.
      userLocked: !userKey,
      locked: !userKey,
    };
  },

  // Home-screen sign-in — accepts EITHER the user or admin password. This
  // does NOT unlock any vault; it only proves someone at this device can
  // use the extension. Vault reads still require a separate VERIFY step.
  async APP_UNLOCK({ password }) {
    if (!password) throw new Error('Password required');
    const uBlob = await loadVaultBlob(SCOPE_USER);
    const aBlob = await loadVaultBlob(SCOPE_ADMIN);
    let ok = false;
    if (uBlob) {
      try {
        const salt = new Uint8Array(b64ToBuf(uBlob.salt));
        const key = await deriveKey(password, salt);
        await decryptString(uBlob.iv, uBlob.ciphertext, key);
        ok = true;
      } catch { /* not user pw */ }
    }
    if (!ok && aBlob) {
      try {
        const salt = new Uint8Array(b64ToBuf(aBlob.salt));
        const key = await deriveKey(password, salt);
        await decryptString(aBlob.iv, aBlob.ciphertext, key);
        ok = true;
      } catch { /* not admin pw */ }
    }
    if (!ok) throw new Error('Wrong password');
    await chrome.storage.session.set({ appUnlocked: true });
    await resetAppAlarm();
    return {};
  },

  async APP_LOCK() {
    await chrome.storage.session.remove('appUnlocked');
    await clearSessionKey(SCOPE_USER);
    await clearSessionKey(SCOPE_ADMIN);
    await chrome.alarms.clear(APP_ALARM);
    await chrome.alarms.clear(USER_ALARM);
    await chrome.alarms.clear(ADMIN_ALARM);
    await updateBadge();
    return {};
  },

  // Lock both vault sessions but KEEP the app-level home-screen unlock.
  // Called after every write so the tab views auto-relock immediately.
  async LOCK_VAULT_SESSIONS() {
    await clearSessionKey(SCOPE_USER);
    await clearSessionKey(SCOPE_ADMIN);
    await chrome.alarms.clear(USER_ALARM);
    await chrome.alarms.clear(ADMIN_ALARM);
    return {};
  },

  // Initial setup: IT sets BOTH passwords at first install.
  async INITIALIZE({ userPassword, adminPassword, password }) {
    await migrateIfNeeded();
    if (await loadVaultBlob(SCOPE_USER)) throw new Error('Already initialized');
    const uPw = userPassword || password;
    if (!uPw || uPw.length < 8) throw new Error('User master password must be at least 8 characters');
    if (adminPassword != null) {
      if (adminPassword.length < 8) throw new Error('Admin master password must be at least 8 characters');
      if (adminPassword === uPw) throw new Error('Admin password must differ from user password');
    }

    // User vault — write it locked. Sign-in happens on the next screen.
    const uSalt = randomSalt();
    const uKey = await deriveKey(uPw, uSalt);
    const uEmpty = { version: 1, entries: [] };
    const uEnc = await encryptString(JSON.stringify(uEmpty), uKey);
    await saveVaultBlob(SCOPE_USER, { version: 1, salt: bufToB64(uSalt), iv: uEnc.iv, ciphertext: uEnc.ciphertext });

    // Admin vault (if provided). Persist the derived admin key so admin
    // entries can autofill without an interactive admin unlock.
    if (adminPassword) {
      const aSalt = randomSalt();
      const aKey = await deriveKey(adminPassword, aSalt);
      const aEmpty = { version: 1, entries: [] };
      const aEnc = await encryptString(JSON.stringify(aEmpty), aKey);
      await saveVaultBlob(SCOPE_ADMIN, { version: 1, salt: bufToB64(aSalt), iv: aEnc.iv, ciphertext: aEnc.ciphertext });
      await setPersistentAdminKey(aKey);
    }

    await updateBadge();
    return {};
  },

  async UNLOCK({ password, scope }) {
    const s = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    const blob = await loadVaultBlob(s);
    if (!blob) throw new Error(s === SCOPE_ADMIN ? 'No admin vault configured' : 'Not initialized');
    const salt = new Uint8Array(b64ToBuf(blob.salt));
    const key = await deriveKey(password, salt);
    try {
      await decryptString(blob.iv, blob.ciphertext, key);
    } catch {
      throw new Error('Wrong password');
    }
    await setSessionKey(s, key);
    if (s === SCOPE_ADMIN) {
      // Re-sync the persistent autofill key in case it drifted (e.g. was
      // wiped by clearPersistentAdminKey during a change-password flow).
      await setPersistentAdminKey(key);
    }
    await resetLockAlarm(s);
    await updateBadge();
    return {};
  },

  async LOCK({ scope }) {
    if (!scope || scope === SCOPE_USER) {
      await clearSessionKey(SCOPE_USER);
      await chrome.alarms.clear(USER_ALARM);
    }
    if (scope === SCOPE_ADMIN || (!scope && false)) {
      // Explicit admin lock only when asked — keeping admin session tied to
      // its own alarm avoids surprising the user.
      await clearSessionKey(SCOPE_ADMIN);
      await chrome.alarms.clear(ADMIN_ALARM);
    }
    await updateBadge();
    return {};
  },

  // Verify a password against the vault's own salt WITHOUT reissuing the
  // session key. Used by the popup to confirm a "save" or "view" action.
  async VERIFY_USER({ password }) {
    const blob = await loadVaultBlob(SCOPE_USER);
    if (!blob) throw new Error('Not initialized');
    const salt = new Uint8Array(b64ToBuf(blob.salt));
    const key = await deriveKey(password, salt);
    try {
      await decryptString(blob.iv, blob.ciphertext, key);
    } catch { throw new Error('Wrong user password'); }
    return {};
  },

  // Verify admin password without changing session state — used by the admin
  // panel to gate destructive actions. Returns a short-lived session unlock.
  async VERIFY_ADMIN({ password }) {
    const blob = await loadVaultBlob(SCOPE_ADMIN);
    if (!blob) throw new Error('No admin vault configured');
    const salt = new Uint8Array(b64ToBuf(blob.salt));
    const key = await deriveKey(password, salt);
    try {
      await decryptString(blob.iv, blob.ciphertext, key);
    } catch {
      throw new Error('Wrong admin password');
    }
    await setSessionKey(SCOPE_ADMIN, key);
    await resetLockAlarm(SCOPE_ADMIN);
    return {};
  },

  async GET_ENTRIES() {
    await resetLockAlarm(SCOPE_USER);
    // User entries only — admin data is fetched via GET_ADMIN_ENTRIES.
    const userVault = await decryptVaultPlaintext(SCOPE_USER);
    const userList = userVault.entries.map((e) => ({
      id: e.id,
      scope: SCOPE_USER,
      title: e.title,
      url: e.url,
      username: e.username,
      password: e.password,
      notes: e.notes,
      updatedAt: e.updatedAt,
    }));
    return { entries: userList };
  },

  // Admin-only: list admin entries with FULL plaintext for the admin UI.
  // Requires the admin session key (VERIFY_ADMIN must have been called), so
  // only someone who typed the admin password reaches this data.
  async GET_ADMIN_ENTRIES() {
    const sKey = await getSessionKey(SCOPE_ADMIN);
    if (!sKey) throw new Error('LOCKED');
    await resetLockAlarm(SCOPE_ADMIN);
    const vault = await decryptVaultPlaintext(SCOPE_ADMIN, sKey);
    return {
      entries: vault.entries.map((e) => ({
        id: e.id,
        title: e.title,
        url: e.url,
        username: e.username,
        password: e.password,
        notes: e.notes,
        updatedAt: e.updatedAt,
      })),
    };
  },

  async GET_ENTRIES_FOR_ORIGIN({ origin }) {
    const target = normalizeOrigin(origin);
    const results = [];

    // User side
    const uKey = await getSessionKey(SCOPE_USER);
    if (uKey) {
      const uVault = await decryptVaultPlaintext(SCOPE_USER);
      for (const e of uVault.entries) {
        const eHost = normalizeOrigin(e.url || '');
        if (!eHost) continue;
        let score = null;
        if (eHost === target) score = 0;
        else if (target.endsWith('.' + eHost)) score = 1;
        else if (eHost.endsWith('.' + target)) score = 2;
        if (score == null) continue;
        results.push({
          score,
          entry: {
            id: e.id,
            scope: SCOPE_USER,
            title: e.title,
            username: e.username,
            password: e.password,
            url: e.url,
          },
        });
      }
    }

    // Admin side — silent autofill via persistent device key. Password stays
    // in background; content.js gets `managed:true` and a placeholder.
    const aKey = await getEffectiveAdminKey();
    if (aKey) {
      try {
        const aVault = await decryptVaultPlaintext(SCOPE_ADMIN, aKey);
        for (const e of aVault.entries) {
          const eHost = normalizeOrigin(e.url || '');
          if (!eHost) continue;
          let score = null;
          if (eHost === target) score = 0;
          else if (target.endsWith('.' + eHost)) score = 1;
          else if (eHost.endsWith('.' + target)) score = 2;
          if (score == null) continue;
          results.push({
            score,
            entry: {
              id: e.id,
              scope: SCOPE_ADMIN,
              managed: true,
              title: e.title,
              username: e.username,
              password: '',     // never sent to content — request via AUTOFILL_MANAGED
              url: e.url,
            },
          });
        }
      } catch { /* ignore */ }
    }

    results.sort((a, b) => a.score - b.score);
    return {
      entries: results.map((r) => r.entry),
      locked: !uKey,
    };
  },

  // Content or popup asks background to fill an admin entry into a specific
  // tab. The password is decrypted here and messaged straight to the tab —
  // it never touches popup/options code.
  async AUTOFILL_MANAGED({ id, tabId }, sender) {
    const aKey = await getEffectiveAdminKey();
    if (!aKey) throw new Error('Admin vault unavailable');
    const vault = await decryptVaultPlaintext(SCOPE_ADMIN, aKey);
    const entry = vault.entries.find((e) => e.id === id);
    if (!entry) throw new Error('Not found');

    // Prefer the caller's own tab (content script) → falls back to the
    // explicit tabId the popup passes → last resort the active tab.
    let targetTabId = sender?.tab?.id ?? tabId;
    let targetUrl = sender?.tab?.url;
    if (!targetTabId) {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (!tab?.id) throw new Error('No active tab');
      targetTabId = tab.id;
      targetUrl = tab.url;
    }
    // Origin sanity check — refuse to autofill into a page that doesn't
    // match the entry's URL, so a rogue site can't yank credentials.
    const tabHost = targetUrl ? normalizeOrigin(targetUrl) : '';
    const entryHost = normalizeOrigin(entry.url || '');
    if (tabHost && !hostsMatch(tabHost, entryHost)) {
      throw new Error('This login is for a different site');
    }
    try {
      await chrome.tabs.sendMessage(targetTabId, {
        type: 'MV_AUTOFILL',
        username: entry.username,
        password: entry.password,
        managed: true,           // instruct content.js to lock + auto-submit
      });
    } catch (e) {
      throw new Error('Cannot fill on this page');
    }
    return {};
  },

  async ADD_ENTRY({ entry, scope }) {
    const s = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    if (s === SCOPE_ADMIN) {
      const sk = await getSessionKey(SCOPE_ADMIN);
      if (!sk) throw new Error('Admin locked');
      await resetLockAlarm(SCOPE_ADMIN);
    } else {
      await resetLockAlarm(SCOPE_USER);
    }
    const key = s === SCOPE_ADMIN ? await getSessionKey(SCOPE_ADMIN) : await getSessionKey(SCOPE_USER);
    if (!key) throw new Error('LOCKED');
    const vault = await decryptVaultPlaintext(s, key);
    const now = Date.now();
    const newEntry = {
      id: crypto.randomUUID(),
      title: entry.title || '',
      url: entry.url || '',
      username: entry.username || '',
      password: entry.password || '',
      notes: entry.notes || '',
      createdAt: now,
      updatedAt: now,
    };
    vault.entries.push(newEntry);
    await encryptAndSaveVault(s, vault, key);
    return { entry: { ...newEntry, scope: s } };
  },

  async UPDATE_ENTRY({ id, entry, scope }) {
    const s = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    if (s === SCOPE_ADMIN) {
      const sk = await getSessionKey(SCOPE_ADMIN);
      if (!sk) throw new Error('Admin locked');
      await resetLockAlarm(SCOPE_ADMIN);
    } else {
      await resetLockAlarm(SCOPE_USER);
    }
    const key = s === SCOPE_ADMIN ? await getSessionKey(SCOPE_ADMIN) : await getSessionKey(SCOPE_USER);
    if (!key) throw new Error('LOCKED');
    const vault = await decryptVaultPlaintext(s, key);
    const idx = vault.entries.findIndex((e) => e.id === id);
    if (idx === -1) throw new Error('Not found');
    const merged = { ...vault.entries[idx], ...entry, updatedAt: Date.now() };
    // Preserve existing password if the caller omitted or blanked it. This
    // matters for admin edits where the popup never sees the current password
    // and only writes when the admin actually types a new one.
    if (entry && (entry.password == null || entry.password === '')) {
      merged.password = vault.entries[idx].password;
    }
    vault.entries[idx] = merged;
    await encryptAndSaveVault(s, vault, key);
    return {};
  },

  async DELETE_ENTRY({ id, scope }) {
    const s = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    if (s === SCOPE_ADMIN) {
      const sk = await getSessionKey(SCOPE_ADMIN);
      if (!sk) throw new Error('Admin locked');
      await resetLockAlarm(SCOPE_ADMIN);
    } else {
      await resetLockAlarm(SCOPE_USER);
    }
    const key = s === SCOPE_ADMIN ? await getSessionKey(SCOPE_ADMIN) : await getSessionKey(SCOPE_USER);
    if (!key) throw new Error('LOCKED');
    const vault = await decryptVaultPlaintext(s, key);
    vault.entries = vault.entries.filter((e) => e.id !== id);
    await encryptAndSaveVault(s, vault, key);
    return {};
  },

  async CHANGE_MASTER({ oldPassword, newPassword, scope }) {
    const s = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    if (!newPassword || newPassword.length < 8) throw new Error('New password must be at least 8 characters');
    const blob = await loadVaultBlob(s);
    if (!blob) throw new Error('Not initialized');
    const oldSalt = new Uint8Array(b64ToBuf(blob.salt));
    const oldKey = await deriveKey(oldPassword, oldSalt);
    let json;
    try {
      json = await decryptString(blob.iv, blob.ciphertext, oldKey);
    } catch {
      throw new Error('Wrong current password');
    }
    const newSalt = randomSalt();
    const newKey = await deriveKey(newPassword, newSalt);
    const { iv, ciphertext } = await encryptString(json, newKey);
    await saveVaultBlob(s, { version: 1, salt: bufToB64(newSalt), iv, ciphertext });
    await setSessionKey(s, newKey);
    if (s === SCOPE_ADMIN) {
      await setPersistentAdminKey(newKey);
    }
    await resetLockAlarm(s);
    return {};
  },

  // Export a single vault. The caller must supply that vault's own master
  // password — the export handler verifies it before returning ciphertext.
  async EXPORT_VAULT({ scope, password }) {
    const s = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    const blob = await loadVaultBlob(s);
    if (!blob) throw new Error('Nothing to export');
    if (!password) throw new Error('Password required');
    const salt = new Uint8Array(b64ToBuf(blob.salt));
    const key = await deriveKey(password, salt);
    try { await decryptString(blob.iv, blob.ciphertext, key); }
    catch { throw new Error(s === SCOPE_ADMIN ? 'Wrong admin password' : 'Wrong user password'); }
    const payload = { app: 'KeyNest', version: 2, scope: s, exportedAt: Date.now(), ...blob };
    return { data: JSON.stringify(payload, null, 2) };
  },

  // Import a backup INTO the existing vault without changing the master
  // password. The entered password must decrypt both the file AND the
  // current vault; imported entries are re-encrypted with the current key
  // and stored under the current salt, so the master password is unchanged.
  async IMPORT_VAULT({ data, password, scope }) {
    let parsed;
    try { parsed = JSON.parse(data); } catch { throw new Error('Invalid file'); }
    if (!parsed.salt || !parsed.iv || !parsed.ciphertext) throw new Error('Invalid vault file');
    const target = scope === SCOPE_ADMIN ? SCOPE_ADMIN : SCOPE_USER;
    const fileScope = parsed.scope === 'admin' ? SCOPE_ADMIN : SCOPE_USER;
    if (fileScope !== target) throw new Error(`This is a ${fileScope} backup — pick "Import ${fileScope} backup" instead`);

    const currentBlob = await loadVaultBlob(target);
    if (!currentBlob) throw new Error('Nothing to import into — vault must be set up first');

    // 1. Decrypt the FILE with the entered password + file's salt.
    const fileSalt = new Uint8Array(b64ToBuf(parsed.salt));
    const fileKey = await deriveKey(password, fileSalt);
    let json;
    try { json = await decryptString(parsed.iv, parsed.ciphertext, fileKey); }
    catch { throw new Error('Wrong password for this file'); }

    // 2. Verify the entered password ALSO matches the CURRENT vault —
    //    otherwise the import would silently rotate the master password.
    const currentSalt = new Uint8Array(b64ToBuf(currentBlob.salt));
    const currentKey = await deriveKey(password, currentSalt);
    try { await decryptString(currentBlob.iv, currentBlob.ciphertext, currentKey); }
    catch {
      throw new Error(
        target === SCOPE_ADMIN
          ? 'This password does not match the current admin password. Import refused so the admin password stays unchanged.'
          : 'This password does not match the current user password. Import refused so the user password stays unchanged.'
      );
    }

    // 3. Re-encrypt the imported entries with the CURRENT key + salt.
    const parsedVault = JSON.parse(json);
    const reEnc = await encryptString(JSON.stringify(parsedVault), currentKey);
    await saveVaultBlob(target, { version: 1, salt: currentBlob.salt, iv: reEnc.iv, ciphertext: reEnc.ciphertext });
    await setSessionKey(target, currentKey);
    if (target === SCOPE_ADMIN) await setPersistentAdminKey(currentKey);
    await resetLockAlarm(target);
    await updateBadge();
    return { count: parsedVault.entries.length };
  },

  async GENERATE_PASSWORD({ options }) {
    return { password: generatePassword(options || {}) };
  },

  async GET_SETTINGS() {
    return { settings: await getSettings() };
  },

  async SAVE_SETTINGS({ settings }) {
    await saveSettings(settings);
    // If the app is currently unlocked, refresh the idle alarm so the new
    // autoLockMinutes takes effect immediately.
    const { appUnlocked } = await chrome.storage.session.get('appUnlocked');
    if (appUnlocked) await resetAppAlarm();
    return {};
  },

  // WIPE_ALL requires BOTH user and admin passwords when both vaults exist.
  async WIPE_ALL({ adminPassword, userPassword }) {
    const userBlob = await loadVaultBlob(SCOPE_USER);
    const adminBlob = await loadVaultBlob(SCOPE_ADMIN);
    if (userBlob) {
      if (!userPassword) throw new Error('User password required');
      const salt = new Uint8Array(b64ToBuf(userBlob.salt));
      const key = await deriveKey(userPassword, salt);
      try { await decryptString(userBlob.iv, userBlob.ciphertext, key); }
      catch { throw new Error('Wrong user password'); }
    }
    if (adminBlob) {
      if (!adminPassword) throw new Error('Admin password required');
      const salt = new Uint8Array(b64ToBuf(adminBlob.salt));
      const key = await deriveKey(adminPassword, salt);
      try { await decryptString(adminBlob.iv, adminBlob.ciphertext, key); }
      catch { throw new Error('Wrong admin password'); }
    }
    await chrome.storage.local.clear();
    await chrome.storage.sync.clear(); // legacy scrub
    await chrome.storage.session.clear();
    await chrome.alarms.clear(USER_ALARM);
    await chrome.alarms.clear(ADMIN_ALARM);
    await chrome.alarms.clear(APP_ALARM);
    await updateBadge();
    return {};
  },

  async SAVE_CAPTURED({ origin, url, username, password }) {
    if (!password) return {};
    await chrome.storage.session.set({
      pendingSave: { origin, url, username, password, ts: Date.now() },
    });
    return {};
  },

  async GET_PENDING_SAVE() {
    const { pendingSave } = await chrome.storage.session.get('pendingSave');
    if (!pendingSave) return { pendingSave: null };
    if (Date.now() - pendingSave.ts > PENDING_SAVE_TTL_MS) {
      await chrome.storage.session.remove('pendingSave');
      return { pendingSave: null };
    }
    return { pendingSave };
  },

  async CLEAR_PENDING_SAVE() {
    await chrome.storage.session.remove('pendingSave');
    return {};
  },

  async OPEN_OPTIONS() {
    await chrome.runtime.openOptionsPage();
    return {};
  },

  async GET_STORAGE_INFO() {
    const bytesInUse = await chrome.storage.local.getBytesInUse(null);
    const totalLimit = chrome.storage.local.QUOTA_BYTES || (10 * 1024 * 1024);
    const uBlob = await loadVaultBlob(SCOPE_USER);
    const aBlob = await loadVaultBlob(SCOPE_ADMIN);
    const userVaultBytes = uBlob ? new TextEncoder().encode(JSON.stringify(uBlob)).length : 0;
    const adminVaultBytes = aBlob ? new TextEncoder().encode(JSON.stringify(aBlob)).length : 0;
    let entryCount = null;
    const uKey = await getSessionKey(SCOPE_USER);
    if (uKey && uBlob) {
      try {
        const v = await decryptVaultPlaintext(SCOPE_USER);
        entryCount = v.entries.length;
      } catch {}
    }
    return {
      bytesInUse,
      totalLimit,
      userVaultBytes,
      adminVaultBytes,
      vaultBytes: userVaultBytes + adminVaultBytes, // legacy field for old options.js
      entryCount,
    };
  },

  async SAVE_FROM_PROMPT({ title, url, username, password }) {
    await resetLockAlarm(SCOPE_USER);
    const key = await getSessionKey(SCOPE_USER);
    if (!key) throw new Error('LOCKED');
    const vault = await decryptVaultPlaintext(SCOPE_USER);
    const origin = normalizeOrigin(url);
    const existing = vault.entries.find((e) => hostsMatch(e.url, origin) && e.username === username);
    const now = Date.now();
    if (existing) {
      existing.password = password;
      existing.updatedAt = now;
    } else {
      vault.entries.push({
        id: crypto.randomUUID(),
        title: title || origin,
        url,
        username,
        password,
        notes: '',
        createdAt: now,
        updatedAt: now,
      });
    }
    await encryptAndSaveVault(SCOPE_USER, vault);
    await chrome.storage.session.remove('pendingSave');
    return {};
  },
};

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  const handler = handlers[msg?.type];
  if (!handler) {
    sendResponse({ ok: false, error: 'Unknown message type: ' + msg?.type });
    return false;
  }
  handler(msg, sender).then(
    (result) => sendResponse({ ok: true, ...(result || {}) }),
    (err) => sendResponse({ ok: false, error: err?.message || String(err) })
  );
  return true;
});

chrome.runtime.onInstalled.addListener(async () => {
  await migrateIfNeeded();
  await updateBadge();
});

chrome.runtime.onStartup.addListener(async () => {
  await migrateIfNeeded();
  await updateBadge();
});
