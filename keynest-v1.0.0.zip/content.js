(() => {
  if (window.__keynest_injected) return;
  window.__keynest_injected = true;

  const ICON_URL = chrome.runtime.getURL('icons/icon32.png');

  let matchingEntries = [];
  let vaultLocked = true;
  let vaultInitialized = false;
  let iconHost = null;         // small icon overlay
  let iconInputRef = null;     // input the icon is currently attached to
  let dropdownHost = null;
  let saveBanner = null;

  function send(type, payload = {}) {
    return new Promise((resolve) => {
      try {
        chrome.runtime.sendMessage({ type, ...payload }, (res) => {
          if (chrome.runtime.lastError) return resolve({ ok: false, error: chrome.runtime.lastError.message });
          resolve(res || { ok: false, error: 'No response' });
        });
      } catch (e) {
        resolve({ ok: false, error: e.message });
      }
    });
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg?.type === 'MV_AUTOFILL') {
      const pwd = findVisiblePasswordField();
      if (pwd) {
        if (msg.managed) {
          fillManaged(pwd, msg.username, msg.password);
        } else {
          fillPair(pwd, msg.username, msg.password);
        }
        sendResponse({ ok: true });
      } else {
        sendResponse({ ok: false, error: 'No password field on page' });
      }
      return true;
    }
    if (msg?.type === 'MV_REFRESH') {
      refreshMatches();
      sendResponse({ ok: true });
      return true;
    }
  });

  // ---------- DOM helpers ----------

  function isVisible(el) {
    if (!el || !el.isConnected) return false;
    if (el.disabled || el.readOnly) return false;
    const style = window.getComputedStyle(el);
    if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0') return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 8 && rect.height > 8;
  }

  function findVisiblePasswordField(scope) {
    const root = scope || document;
    const inputs = root.querySelectorAll('input[type="password"]');
    for (const inp of inputs) if (isVisible(inp)) return inp;
    return null;
  }

  function isLikelyUsernameField(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    const t = (el.type || 'text').toLowerCase();
    if (['text', 'email', 'tel', 'search', ''].indexOf(t) === -1) return false;
    if (t === 'search') return false;
    const hints = [(el.name || ''), (el.id || ''), (el.autocomplete || ''), (el.placeholder || ''), (el.getAttribute('aria-label') || '')]
      .join(' ')
      .toLowerCase();
    if (/user|email|login|account|phone|mobile|handle/.test(hints)) return true;
    // Fallback: is there a password field nearby (same form or same doc)?
    const scope = el.form || document;
    return !!findVisiblePasswordField(scope);
  }

  function isLoginField(el) {
    if (!(el instanceof HTMLInputElement)) return false;
    if (el.type === 'password') return true;
    return isLikelyUsernameField(el);
  }

  function nearestScopeContainingPassword(el) {
    // Walk up to the smallest ancestor that contains a visible password field.
    let node = el?.parentElement;
    while (node && node !== document.body) {
      if (findVisiblePasswordField(node)) return node;
      node = node.parentElement;
    }
    return document;
  }

  function findUsernameFieldNear(pwdField) {
    const scope = pwdField.form || nearestScopeContainingPassword(pwdField);
    const candidates = Array.from(scope.querySelectorAll('input'));
    const pwdIdx = candidates.indexOf(pwdField);
    for (let i = pwdIdx - 1; i >= 0; i--) {
      const t = (candidates[i].type || 'text').toLowerCase();
      if (['text', 'email', 'tel', ''].indexOf(t) !== -1 && isVisible(candidates[i])) {
        return candidates[i];
      }
    }
    for (let i = pwdIdx + 1; i < candidates.length; i++) {
      const t = (candidates[i].type || 'text').toLowerCase();
      if (['text', 'email', 'tel', ''].indexOf(t) !== -1 && isVisible(candidates[i])) {
        return candidates[i];
      }
    }
    return null;
  }

  function findPasswordFieldFor(input) {
    if (input.type === 'password') return input;
    if (input.form) return findVisiblePasswordField(input.form);
    // No form — climb ancestors to find the smallest section containing a password field.
    return findVisiblePasswordField(nearestScopeContainingPassword(input));
  }

  function nativeSet(el, value) {
    const proto = el.tagName === 'TEXTAREA'
      ? window.HTMLTextAreaElement.prototype
      : window.HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value').set;
    setter.call(el, value);
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
  }

  function fillPair(pwdOrUser, username, password) {
    const pwd = pwdOrUser.type === 'password' ? pwdOrUser : findPasswordFieldFor(pwdOrUser);
    let user = null;
    if (pwd) user = findUsernameFieldNear(pwd);
    else if (isLikelyUsernameField(pwdOrUser)) user = pwdOrUser;

    if (user && username) nativeSet(user, username);
    if (pwd && password) nativeSet(pwd, password);
    (pwd || user)?.focus();
  }

  // Suppress the save-prompt / SAVE_CAPTURED flow for a short window after
  // a managed (admin) autofill. Without this, the form's submit handler
  // (or the doc-level click capture) would read the admin plaintext out of
  // the field and offer it up as a "save this login" for the USER vault —
  // silently leaking admin passwords into user-owned data.
  let suppressCaptureUntil = 0;

  // Managed (admin) autofill: fill, guard the field against reveal, then
  // trigger form submit so the value leaves the DOM quickly.
  function fillManaged(pwdOrUser, username, password) {
    const pwd = pwdOrUser.type === 'password' ? pwdOrUser : findPasswordFieldFor(pwdOrUser);
    let user = null;
    if (pwd) user = findUsernameFieldNear(pwd);
    else if (isLikelyUsernameField(pwdOrUser)) user = pwdOrUser;

    // Tag the fields AND set a time-based backstop so any SAVE_CAPTURED
    // triggered by the ensuing submit is dropped.
    suppressCaptureUntil = Date.now() + 15000;
    if (pwd) pwd.__mvNoCapture = true;
    if (user) user.__mvNoCapture = true;

    if (user && username) nativeSet(user, username);
    if (pwd && password) {
      nativeSet(pwd, password);
      guardManagedField(pwd);
    }
    // Auto-submit so the plaintext leaves the DOM before the user can react.
    const form = (pwd || user)?.form;
    setTimeout(() => {
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
        if (submitBtn && isVisible(submitBtn)) { submitBtn.click(); return; }
        try { form.requestSubmit(); return; } catch (_) {}
        try { form.submit(); return; } catch (_) {}
      }
      // No form — hunt for a visible submit-looking button.
      const buttons = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"]'));
      const btn = buttons.find((b) => {
        if (!isVisible(b)) return false;
        const txt = (b.textContent || b.value || '').trim().toLowerCase();
        return /^(sign in|log in|login|submit|continue|next)$/i.test(txt);
      });
      if (btn) btn.click();
    }, 120);
  }

  // Watches an input for reveal attempts and blanks the value if the site
  // toggles type=password → type=text (or a wrapper's data attributes flip).
  // Also blanks the field on unload so nothing lingers if submit fails.
  function guardManagedField(input) {
    if (!input || input.__mvGuarded) return;
    input.__mvGuarded = true;
    try {
      const obs = new MutationObserver((records) => {
        for (const r of records) {
          if (r.attributeName === 'type' && input.type !== 'password') {
            // Site tried to un-mask the admin password — wipe it.
            nativeSet(input, '');
            try { input.type = 'password'; } catch (_) {}
          }
        }
      });
      obs.observe(input, { attributes: true, attributeFilter: ['type'] });
      // If the input is disconnected from the DOM (SPA nav), the observer
      // is discarded automatically; nothing else to clean up.
    } catch (_) { /* ignore */ }
    // Clear on page unload just in case something kept the DOM alive.
    window.addEventListener('pagehide', () => { try { nativeSet(input, ''); } catch (_) {} }, { once: true });
  }

  function fillAndSubmit(sourceInput, entry) {
    const pwd = findPasswordFieldFor(sourceInput);
    const user = pwd ? findUsernameFieldNear(pwd) : (isLikelyUsernameField(sourceInput) ? sourceInput : null);

    if (user && entry.username) nativeSet(user, entry.username);
    if (pwd && entry.password) nativeSet(pwd, entry.password);

    const form = (pwd || user || sourceInput).form;
    setTimeout(() => {
      if (form) {
        const submitBtn = form.querySelector('button[type="submit"], input[type="submit"], button:not([type])');
        if (submitBtn && isVisible(submitBtn)) {
          submitBtn.click();
          return;
        }
        try { form.requestSubmit(); return; } catch (_) {}
        try { form.submit(); return; } catch (_) {}
      }
      // No form — try clicking any nearby button whose text looks like login/submit
      const buttons = Array.from(document.querySelectorAll('button, [role="button"], input[type="submit"]'));
      const btn = buttons.find((b) => {
        if (!isVisible(b)) return false;
        const txt = (b.textContent || b.value || '').trim().toLowerCase();
        return /^(sign in|log in|login|submit|continue|next)$/i.test(txt);
      });
      if (btn) btn.click();
    }, 120);
  }

  // ---------- Shadow-DOM overlays ----------

  function makeShadowHost(fixed) {
    const host = document.createElement('div');
    host.style.cssText = `position:${fixed ? 'fixed' : 'absolute'};top:0;left:0;z-index:2147483647;pointer-events:auto;`;
    const shadow = host.attachShadow({ mode: 'closed' });
    return { host, shadow };
  }

  const BASE_STYLE = `
    :host, .mv-root { all: initial; }
    .mv-root { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #eef0f3; }
    .mv-icon {
      width: 24px; height: 24px;
      background-color: transparent;
      background-image: url("${ICON_URL}");
      background-size: contain;
      background-position: center;
      background-repeat: no-repeat;
      filter: drop-shadow(0 2px 4px rgba(0,0,0,0.28));
      cursor: pointer;
      transition: transform 0.08s ease, filter 0.08s ease;
    }
    .mv-icon:hover { transform: scale(1.1); filter: drop-shadow(0 3px 8px rgba(0,0,0,0.35)); }
    .mv-dropdown {
      background: #1f2126;
      border: 1px solid #2c2f37;
      border-radius: 16px;
      box-shadow: 0 14px 40px rgba(0,0,0,0.5);
      padding: 6px;
      min-width: 260px;
      max-width: 360px;
      max-height: 320px;
      overflow: auto;
    }
    .mv-item {
      padding: 9px 10px;
      cursor: pointer;
      border-radius: 12px;
      font-size: 12px;
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .mv-item:hover { background: #282b32; }
    .mv-item .mv-avatar {
      position: relative;
      width: 28px; height: 28px; border-radius: 10px; flex: 0 0 auto;
      background: #262832;
      color: #c6cad4;
      font-weight: 700;
      font-size: 12px;
      display: flex; align-items: center; justify-content: center;
      overflow: hidden;
    }
    .mv-item .mv-avatar img {
      position: absolute; inset: 0; width: 100%; height: 100%; object-fit: contain;
      background: rgba(255,255,255,0.98);
    }
    .mv-item .mv-avatar.mv-avatar-managed::after {
      content: '';
      position: absolute;
      right: -3px; bottom: -3px;
      width: 12px; height: 12px;
      border-radius: 50%;
      background: linear-gradient(135deg, #7c9cff 0%, #a677ff 100%);
      border: 2px solid #1f2126;
    }
    .mv-pill {
      display: inline-block;
      padding: 1px 6px;
      border-radius: 999px;
      font-size: 9px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      background: rgba(124,156,255,0.18);
      color: #7c9cff;
      border: 1px solid rgba(124,156,255,0.30);
      vertical-align: middle;
      margin-right: 4px;
    }
    .mv-item .mv-text { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
    .mv-item .mv-user { color: #eef0f3; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .mv-item .mv-sub { color: #8b90a0; font-size: 11px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .mv-empty {
      padding: 14px 12px;
      font-size: 12px;
      color: #8b90a0;
      text-align: center;
    }
    .mv-empty a { color: #6aa9ff; cursor: pointer; text-decoration: underline; }
    .mv-header {
      padding: 6px 10px 4px;
      font-size: 10px;
      color: #8b90a0;
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }
    .mv-footer {
      padding: 6px 10px;
      border-top: 1px solid #2c2f37;
      margin-top: 4px;
      font-size: 11px;
      color: #8b90a0;
      cursor: pointer;
      text-align: center;
    }
    .mv-footer:hover { color: #eef0f3; }
    .mv-unlock { padding: 12px 12px 10px; }
    .mv-unlock-label {
      font-size: 12px;
      color: #eef0f3;
      margin-bottom: 8px;
      font-weight: 600;
    }
    .mv-unlock-row { display: flex; gap: 6px; }
    .mv-unlock-input {
      flex: 1;
      padding: 9px 12px;
      background: #14161a;
      border: 1px solid #2c2f37;
      color: #eef0f3;
      border-radius: 12px;
      font-size: 12px;
      font-family: inherit;
      min-width: 0;
      outline: none;
    }
    .mv-unlock-input:focus { border-color: #7c9cff; }
    .mv-unlock-btn {
      background: linear-gradient(135deg, #7c9cff 0%, #a677ff 100%);
      color: #ffffff; border: none; border-radius: 999px;
      padding: 9px 16px; font-size: 12px; font-weight: 600; cursor: pointer;
      font-family: inherit;
      box-shadow: 0 2px 8px rgba(124, 156, 255, 0.28);
    }
    .mv-unlock-btn:hover:not(:disabled) { filter: brightness(1.08); }
    .mv-unlock-btn:disabled { opacity: 0.5; cursor: not-allowed; }
    .mv-unlock-err {
      font-size: 11px;
      color: #ff5c66;
      margin-top: 6px;
      min-height: 14px;
    }
    .mv-banner {
      background: #1f2126;
      border: 1px solid #2c2f37;
      border-radius: 18px;
      padding: 14px 16px;
      box-shadow: 0 14px 40px rgba(0,0,0,0.45);
      font-size: 13px;
      color: #eef0f3;
      display: flex;
      align-items: center;
      gap: 12px;
      max-width: 400px;
    }
    .mv-banner .mv-icon { flex: 0 0 auto; }
    .mv-banner .text { flex: 1; }
    .mv-banner .text b { color: #7c9cff; }
    .mv-banner button {
      background: linear-gradient(135deg, #7c9cff 0%, #a677ff 100%);
      color: #ffffff; border: none; border-radius: 999px;
      padding: 7px 14px; font-size: 12px; font-weight: 600; cursor: pointer;
      font-family: inherit;
      box-shadow: 0 2px 8px rgba(124, 156, 255, 0.28);
    }
    .mv-banner button.ghost { background: transparent; color: #8b90a0; padding: 6px 10px; box-shadow: none; }
    .mv-banner button:hover { filter: brightness(1.08); }
  `;

  // ---------- Icon in field ----------

  function removeIcon() {
    if (iconHost) { iconHost.remove(); iconHost = null; iconInputRef = null; }
    removeDropdown();
  }

  function positionIcon() {
    if (!iconHost || !iconInputRef || !iconInputRef.isConnected) { removeIcon(); return; }
    if (!isVisible(iconInputRef)) { removeIcon(); return; }
    const rect = iconInputRef.getBoundingClientRect();
    iconHost.style.top = (rect.top + rect.height / 2 - 12) + 'px';
    iconHost.style.left = (rect.right - 30) + 'px';
  }

  function showIconOn(input) {
    if (iconInputRef === input && iconHost) { positionIcon(); return; }
    removeIcon();
    const { host, shadow } = makeShadowHost(true);
    const style = document.createElement('style');
    style.textContent = BASE_STYLE;
    shadow.appendChild(style);
    const root = document.createElement('div');
    root.className = 'mv-root';
    const icon = document.createElement('div');
    icon.className = 'mv-icon';
    icon.title = 'KeyNest — click for saved logins';
    icon.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleDropdown(input);
    });
    root.appendChild(icon);
    shadow.appendChild(root);
    document.body.appendChild(host);
    iconHost = host;
    iconInputRef = input;
    positionIcon();
  }

  // ---------- Dropdown ----------

  function removeDropdown() {
    if (dropdownHost) { dropdownHost.remove(); dropdownHost = null; }
  }

  function positionDropdown() {
    if (!dropdownHost || !iconInputRef) return;
    const rect = iconInputRef.getBoundingClientRect();
    dropdownHost.style.top = (rect.bottom + 6) + 'px';
    dropdownHost.style.left = rect.left + 'px';
    dropdownHost.style.minWidth = Math.max(240, rect.width) + 'px';
  }

  function toggleDropdown(input) {
    if (dropdownHost && iconInputRef === input) { removeDropdown(); return; }
    removeDropdown();
    renderDropdown(input);
  }

  function renderDropdown(input) {
    const { host, shadow } = makeShadowHost(true);
    const style = document.createElement('style');
    style.textContent = BASE_STYLE;
    shadow.appendChild(style);
    const root = document.createElement('div');
    root.className = 'mv-root';
    const dd = document.createElement('div');
    dd.className = 'mv-dropdown';

    if (!vaultInitialized) {
      const empty = document.createElement('div');
      empty.className = 'mv-empty';
      empty.textContent = 'Set up KeyNest from the toolbar icon first.';
      dd.appendChild(empty);
      addFooter(dd, 'Manage in KeyNest', () => send('OPEN_OPTIONS'));
    } else if (vaultLocked) {
      renderUnlockForm(dd, input, shadow);
    } else if (matchingEntries.length === 0) {
      const empty = document.createElement('div');
      empty.className = 'mv-empty';
      empty.innerHTML = 'No saved logins for <b>' + escapeHtml(location.hostname) + '</b>.';
      dd.appendChild(empty);
      addFooter(dd, 'Manage in KeyNest', () => send('OPEN_OPTIONS'));
    } else {
      const header = document.createElement('div');
      header.className = 'mv-header';
      header.textContent = 'Saved for ' + location.hostname;
      dd.appendChild(header);

      for (const e of matchingEntries) {
        const item = document.createElement('div');
        item.className = 'mv-item';
        const fav = faviconEl(e.url, e.title);
        if (e.managed) fav.classList.add('mv-avatar-managed');
        item.appendChild(fav);
        const text = document.createElement('div');
        text.className = 'mv-text';
        const user = document.createElement('div');
        user.className = 'mv-user';
        user.textContent = e.username || '(no username)';
        const sub = document.createElement('div');
        sub.className = 'mv-sub';
        if (e.managed) {
          const pill = document.createElement('span');
          pill.className = 'mv-pill';
          pill.textContent = 'Admin';
          sub.appendChild(pill);
          sub.appendChild(document.createTextNode(' ' + (e.title || safeHost(e.url) || 'Managed login')));
        } else {
          sub.textContent = e.title || safeHost(e.url) || 'Login';
        }
        text.appendChild(user);
        text.appendChild(sub);
        item.appendChild(text);
        item.addEventListener('mousedown', async (ev) => {
          ev.preventDefault();
          ev.stopPropagation();
          removeDropdown();
          if (e.managed) {
            // Password never leaves the service worker: background reads it,
            // messages MV_AUTOFILL back to this tab, and we fill.
            const res = await send('AUTOFILL_MANAGED', { id: e.id });
            if (!res.ok) console.warn('KeyNest managed fill:', res.error);
          } else {
            fillAndSubmit(input, e);
          }
        });
        dd.appendChild(item);
      }
      addFooter(dd, 'Manage in KeyNest', () => send('OPEN_OPTIONS'));
    }

    root.appendChild(dd);
    shadow.appendChild(root);
    document.body.appendChild(host);
    dropdownHost = host;
    positionDropdown();
  }

  function addFooter(dd, text, onClick) {
    const footer = document.createElement('div');
    footer.className = 'mv-footer';
    footer.textContent = text;
    footer.addEventListener('mousedown', (ev) => {
      ev.preventDefault();
      removeDropdown();
      onClick();
    });
    dd.appendChild(footer);
  }

  function renderUnlockForm(dd, input, shadow) {
    const wrap = document.createElement('div');
    wrap.className = 'mv-unlock';

    const label = document.createElement('div');
    label.className = 'mv-unlock-label';
    label.innerHTML = '🔒 Unlock vault';
    wrap.appendChild(label);

    const row = document.createElement('div');
    row.className = 'mv-unlock-row';
    const pwd = document.createElement('input');
    pwd.type = 'password';
    pwd.placeholder = 'User master password';
    pwd.className = 'mv-unlock-input';
    pwd.autocomplete = 'off';
    const btn = document.createElement('button');
    btn.type = 'button';
    btn.textContent = 'Unlock';
    btn.className = 'mv-unlock-btn';
    row.appendChild(pwd);
    row.appendChild(btn);
    wrap.appendChild(row);

    const err = document.createElement('div');
    err.className = 'mv-unlock-err';
    wrap.appendChild(err);

    const submit = async () => {
      err.textContent = '';
      const val = pwd.value;
      if (!val) return;
      btn.disabled = true;
      const res = await send('UNLOCK', { password: val, scope: 'user' });
      if (!res.ok) {
        err.textContent = res.error || 'Wrong password';
        btn.disabled = false;
        pwd.select();
        return;
      }
      await refreshMatches();
      // Re-render the dropdown with the now-unlocked view
      removeDropdown();
      renderDropdown(input);
    };

    btn.addEventListener('mousedown', (e) => { e.preventDefault(); });
    btn.addEventListener('click', submit);
    pwd.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); submit(); }
    });
    // Prevent site JS from stealing focus
    pwd.addEventListener('mousedown', (e) => e.stopPropagation());

    dd.appendChild(wrap);
    setTimeout(() => pwd.focus(), 30);
  }

  // ---------- Bindings ----------

  async function refreshMatches() {
    const res = await send('CHECK_STATE');
    if (res.ok) {
      vaultInitialized = res.initialized;
      vaultLocked = res.locked;
    }
    if (vaultInitialized && !vaultLocked) {
      const r = await send('GET_ENTRIES_FOR_ORIGIN', { origin: location.hostname });
      if (r.ok) {
        matchingEntries = r.entries || [];
        vaultLocked = r.locked || false;
      }
    } else {
      matchingEntries = [];
    }
  }

  function onFocusIn(e) {
    const el = e.target;
    if (!isLoginField(el)) return;
    showIconOn(el);
  }

  function onFocusOut(e) {
    // Delay so click on the icon works before we hide it
    setTimeout(() => {
      if (!document.activeElement || !isLoginField(document.activeElement)) {
        if (!dropdownHost) removeIcon();
      }
    }, 200);
  }

  function onDocPointerDown(e) {
    if (!dropdownHost) return;
    const path = e.composedPath ? e.composedPath() : [];
    if (path.includes(dropdownHost) || path.includes(iconHost) || e.target === iconInputRef) return;
    removeDropdown();
  }

  document.addEventListener('focusin', onFocusIn, true);
  document.addEventListener('focusout', onFocusOut, true);
  document.addEventListener('mousedown', onDocPointerDown, true);
  window.addEventListener('scroll', () => { positionIcon(); positionDropdown(); }, true);
  window.addEventListener('resize', () => { positionIcon(); positionDropdown(); });

  // ---------- Submit capture (for save prompt) ----------

  const attachedForms = new WeakSet();
  function attachSubmitCapture() {
    const forms = document.querySelectorAll('form');
    for (const form of forms) {
      if (attachedForms.has(form)) continue;
      if (!form.querySelector('input[type="password"]')) continue;
      attachedForms.add(form);
      form.addEventListener('submit', () => captureFromForm(form), true);
    }
  }

  function isCaptureSuppressed(pwd, userField) {
    if (Date.now() < suppressCaptureUntil) return true;
    if (pwd && pwd.__mvNoCapture) return true;
    if (userField && userField.__mvNoCapture) return true;
    return false;
  }

  async function captureFromForm(form) {
    const pwd = form.querySelector('input[type="password"]');
    if (!pwd || !pwd.value) return;
    const userField = findUsernameFieldNear(pwd);
    if (isCaptureSuppressed(pwd, userField)) return;
    await send('SAVE_CAPTURED', {
      origin: location.hostname,
      url: location.href,
      username: userField ? userField.value : '',
      password: pwd.value,
    });
  }

  document.addEventListener('click', async (e) => {
    const btn = e.target.closest('button, [role="button"], input[type="submit"]');
    if (!btn) return;
    const pwd = findVisiblePasswordField();
    if (!pwd || !pwd.value) return;
    if (btn.form) return;
    const userField = findUsernameFieldNear(pwd);
    if (isCaptureSuppressed(pwd, userField)) return;
    await send('SAVE_CAPTURED', {
      origin: location.hostname,
      url: location.href,
      username: userField ? userField.value : '',
      password: pwd.value,
    });
  }, true);

  const formObserver = new MutationObserver(() => attachSubmitCapture());
  formObserver.observe(document.documentElement, { childList: true, subtree: true });

  // ---------- Save-prompt banner ----------

  function removeBanner() { if (saveBanner) { saveBanner.remove(); saveBanner = null; } }

  function showSaveBanner(pending, isUpdate) {
    removeBanner();
    const { host, shadow } = makeShadowHost(true);
    host.style.top = 'auto';
    host.style.left = 'auto';
    host.style.right = '16px';
    host.style.bottom = '16px';
    const style = document.createElement('style');
    style.textContent = BASE_STYLE;
    shadow.appendChild(style);

    const root = document.createElement('div');
    root.className = 'mv-root';
    const banner = document.createElement('div');
    banner.className = 'mv-banner';

    const icon = document.createElement('div');
    icon.className = 'mv-icon';

    const text = document.createElement('div');
    text.className = 'text';
    text.innerHTML = isUpdate
      ? `Update saved password for <b>${escapeHtml(pending.username || pending.origin)}</b>?`
      : `Save this login for <b>${escapeHtml(pending.origin)}</b>?`;

    const saveBtn = document.createElement('button');
    saveBtn.textContent = isUpdate ? 'Update' : 'Save';
    saveBtn.addEventListener('click', async () => {
      const res = await send('SAVE_FROM_PROMPT', {
        title: pending.origin,
        url: pending.url,
        username: pending.username,
        password: pending.password,
      });
      if (res.ok) {
        removeBanner();
        refreshMatches();
      } else {
        text.textContent = 'Error: ' + res.error;
        setTimeout(removeBanner, 2500);
      }
    });

    const dismissBtn = document.createElement('button');
    dismissBtn.className = 'ghost';
    dismissBtn.textContent = 'Not now';
    dismissBtn.addEventListener('click', async () => {
      await send('CLEAR_PENDING_SAVE');
      removeBanner();
    });

    banner.appendChild(icon);
    banner.appendChild(text);
    banner.appendChild(saveBtn);
    banner.appendChild(dismissBtn);
    root.appendChild(banner);
    shadow.appendChild(root);
    document.body.appendChild(host);
    saveBanner = host;

    setTimeout(() => { if (saveBanner === host) removeBanner(); }, 20000);
  }

  async function checkPendingSave() {
    const res = await send('GET_PENDING_SAVE');
    if (!res.ok || !res.pendingSave) return;
    const p = res.pendingSave;
    const originMatches = hostsMatch(p.origin, location.hostname) ||
      (document.referrer && (() => { try { return hostsMatch(new URL(document.referrer).hostname, p.origin); } catch { return false; } })());
    if (!originMatches) return;
    const matches = await send('GET_ENTRIES_FOR_ORIGIN', { origin: p.origin });
    if (matches.locked) return;
    const existing = (matches.entries || []).find((e) => e.username === p.username);
    if (existing && existing.password === p.password) {
      await send('CLEAR_PENDING_SAVE');
      return;
    }
    showSaveBanner(p, !!existing);
  }

  function hostsMatch(a, b) {
    if (!a || !b) return false;
    a = String(a).toLowerCase();
    b = String(b).toLowerCase();
    if (a === b) return true;
    return a.endsWith('.' + b) || b.endsWith('.' + a);
  }

  function safeHost(url) { try { return new URL(url).hostname; } catch { return ''; } }

  function faviconEl(url, title) {
    const host = safeHost(url);
    const wrap = document.createElement('div');
    wrap.className = 'mv-avatar';
    const letter = ((title || host || '?')[0] || '?').toUpperCase();
    wrap.textContent = letter;
    if (host) {
      const img = document.createElement('img');
      img.src = `https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&sz=64`;
      img.loading = 'lazy';
      img.alt = '';
      img.addEventListener('error', () => img.remove());
      wrap.appendChild(img);
    }
    return wrap;
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ---------- Boot ----------

  refreshMatches().then(attachSubmitCapture);
  if (document.readyState === 'complete') checkPendingSave();
  else window.addEventListener('load', checkPendingSave);
})();
