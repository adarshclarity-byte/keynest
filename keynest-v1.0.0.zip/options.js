const app = document.getElementById('app');
const LOGO_URL = chrome.runtime.getURL('icons/icon128.png');

function send(type, payload = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...payload }, (res) => resolve(res || { ok: false, error: 'No response' }));
  });
}

function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k === 'onclick') el.addEventListener('click', v);
    else if (k === 'html') el.innerHTML = v;
    else if (v !== undefined && v !== null && v !== false) el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}

function msgBox(text, kind = 'info') {
  return h('div', { class: 'msg ' + kind }, text);
}

// Password input with a show/hide eye toggle. Returns { input, wrap }.
function passwordWithEye(attrs = {}) {
  const input = h('input', { type: 'password', autocomplete: 'off', ...attrs });
  const btn = h('button', { type: 'button', class: 'eye-toggle', onclick: () => {
    input.type = input.type === 'password' ? 'text' : 'password';
    btn.textContent = input.type === 'password' ? 'show' : 'hide';
  }}, 'show');
  const wrap = h('div', { class: 'pw-wrap' }, input, btn);
  return { input, wrap };
}

// ---------- tiny styled modal (no window.prompt anywhere) ----------

function confirmDelete() {
  return showModal((modal, close) => {
    const input = h('input', { type: 'text', placeholder: 'Type DELETE to confirm', autocomplete: 'off' });
    const go = h('button', { class: 'btn danger', onclick: () => close(input.value === 'DELETE') }, 'Wipe');
    const cancel = h('button', { class: 'btn secondary', onclick: () => close(false) }, 'Cancel');
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go.click(); if (e.key === 'Escape') close(false); });
    modal.appendChild(h('h3', {}, 'Wipe everything?'));
    modal.appendChild(h('p', { class: 'sub' }, 'This deletes both vaults on this device. Cannot be undone.'));
    modal.appendChild(input);
    modal.appendChild(h('div', { class: 'row', style: 'margin-top:12px;' }, go, cancel));
    setTimeout(() => input.focus(), 40);
  });
}

function showModal(build) {
  return new Promise((resolve) => {
    const backdrop = h('div', { class: 'opt-modal-backdrop' });
    let done = false;
    function close(v) { if (done) return; done = true; backdrop.remove(); resolve(v); }
    const modal = h('div', { class: 'opt-modal' });
    build(modal, close);
    backdrop.appendChild(modal);
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(null); });
    document.body.appendChild(backdrop);
  });
}

function formatBytes(n) {
  if (n < 1024) return { value: n, unit: 'B' };
  const kb = n / 1024;
  if (kb < 1024) return { value: kb.toFixed(1), unit: 'KB' };
  return { value: (kb / 1024).toFixed(2), unit: 'MB' };
}

function safeHost(url) { try { return new URL(url).hostname; } catch { return ''; } }

function pageHeader() {
  return h('div', { class: 'page-header' },
    h('div', { class: 'logo', style: `background-image:url("${LOGO_URL}")` }),
    h('div', {},
      h('h1', {}, 'KeyNest'),
      h('div', { class: 'subtitle' }, 'Settings & backups')
    )
  );
}

async function render() {
  app.innerHTML = '';
  app.appendChild(pageHeader());

  const state = await send('CHECK_STATE');
  const settings = (await send('GET_SETTINGS')).settings || {};

  if (!state.initialized) {
    app.appendChild(h('div', { class: 'card' },
      h('div', { class: 'card-title' }, 'No vault yet'),
      h('p', { class: 'card-hint' }, 'Open the KeyNest toolbar popup to run first-time setup.')
    ));
    return;
  }

  app.appendChild(await renderStorageCard());
  app.appendChild(renderAutoLockCard(settings));
  app.appendChild(renderChangePasswordCard(state));
  app.appendChild(renderBackupCard(state));
  app.appendChild(renderWipeCard(state));
}

// ---------- Storage ----------

async function renderStorageCard() {
  app.appendChild(h('h2', {}, 'Storage'));
  const card = h('div', { class: 'card' });
  card.appendChild(h('div', { class: 'card-title' }, 'Vault storage usage'));
  card.appendChild(h('p', { class: 'card-hint' },
    'Your encrypted vaults live in chrome.storage.local on this device (~10 MB limit). Admin-managed entries are per-device and do not sync.'));

  const res = await send('GET_STORAGE_INFO');
  const info = res.ok ? res : { bytesInUse: 0, totalLimit: 10 * 1024 * 1024, userVaultBytes: 0, adminVaultBytes: 0, entryCount: null };
  const used = info.bytesInUse || 0;
  const limit = info.totalLimit || (10 * 1024 * 1024);
  const pct = Math.min(100, Math.round((used / limit) * 100));

  const stats = h('div', { class: 'storage-stats' });
  const usedFmt = formatBytes(used);
  const uFmt = formatBytes(info.userVaultBytes || 0);
  const aFmt = formatBytes(info.adminVaultBytes || 0);
  stats.appendChild(h('div', { class: 'stat' },
    h('div', { class: 'label' }, 'Used'),
    h('div', { class: 'value' }, String(usedFmt.value), h('span', { class: 'unit' }, ' ' + usedFmt.unit))
  ));
  stats.appendChild(h('div', { class: 'stat' },
    h('div', { class: 'label' }, 'User vault'),
    h('div', { class: 'value' }, String(uFmt.value), h('span', { class: 'unit' }, ' ' + uFmt.unit))
  ));
  stats.appendChild(h('div', { class: 'stat' },
    h('div', { class: 'label' }, 'Admin vault'),
    h('div', { class: 'value' }, String(aFmt.value), h('span', { class: 'unit' }, ' ' + aFmt.unit))
  ));
  card.appendChild(stats);

  const bar = h('div', { class: pct >= 90 ? 'progress crit' : pct >= 70 ? 'progress warn' : 'progress' },
    h('div', { class: 'bar', style: `width:${Math.max(1, pct)}%;` })
  );
  card.appendChild(bar);
  return card;
}

function renderAutoLockCard(settings) {
  app.appendChild(h('h2', {}, 'Auto-lock'));
  const card = h('div', { class: 'card' });
  card.appendChild(h('div', { class: 'card-title' }, 'Idle timeout'));
  card.appendChild(h('p', { class: 'card-hint' }, 'Lock the vault after N minutes of inactivity. Set to 0 to disable (not recommended).'));

  const input = h('input', { type: 'number', min: '0', max: '1440', value: settings.autoLockMinutes ?? 10 });
  const msg = h('div');
  card.appendChild(h('div', { class: 'form-row' },
    h('label', {}, 'Lock after (minutes)'),
    input,
    h('button', { class: 'btn', onclick: async () => {
      const v = parseInt(input.value, 10);
      if (isNaN(v) || v < 0) { msg.replaceChildren(msgBox('Enter a number ≥ 0', 'error')); return; }
      const res = await send('SAVE_SETTINGS', { settings: { ...settings, autoLockMinutes: v } });
      msg.replaceChildren(res.ok ? msgBox('Saved', 'success') : msgBox(res.error, 'error'));
    }}, 'Save'),
  ));
  card.appendChild(msg);
  return card;
}

// ---------- Backup (user + admin, separate) ----------

function askPassword({ scope }) {
  const label = scope === 'admin' ? 'Admin' : 'User';
  return showModal((modal, close) => {
    const pw = passwordWithEye({ placeholder: `${label} password` });
    const err = h('div');
    const go = h('button', { class: 'btn', onclick: () => close(pw.input.value || null) }, 'Continue');
    const cancel = h('button', { class: 'btn secondary', onclick: () => close(null) }, 'Cancel');
    pw.input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go.click(); if (e.key === 'Escape') close(null); });
    modal.appendChild(h('h3', {}, `Enter ${label.toLowerCase()} password`));
    modal.appendChild(h('p', { class: 'sub' }, `Required to export the ${label.toLowerCase()} vault.`));
    modal.appendChild(pw.wrap);
    modal.appendChild(err);
    modal.appendChild(h('div', { class: 'row', style: 'margin-top:12px;' }, go, cancel));
    setTimeout(() => pw.input.focus(), 40);
  });
}

async function doExport(scope) {
  const password = await askPassword({ scope });
  if (!password) return { cancelled: true };
  const res = await send('EXPORT_VAULT', { scope, password });
  if (!res.ok) return { ok: false, error: res.error };
  const blob = new Blob([res.data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `keynest-${scope}-backup-${new Date().toISOString().slice(0, 10)}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return { ok: true };
}

async function openImportDialog(scope) {
  const label = scope === 'admin' ? 'Admin' : 'User';
  const result = await showModal((modal, close) => {
    const file = h('input', { type: 'file', accept: '.json,application/json' });
    const pw = passwordWithEye({ placeholder: `${label} password` });
    const err = h('div');
    const go = h('button', { class: 'btn', onclick: async () => {
      const f = file.files?.[0];
      if (!f) { err.replaceChildren(msgBox('Choose a file', 'error')); return; }
      if (!pw.input.value) { err.replaceChildren(msgBox('Enter the password', 'error')); return; }
      const text = await f.text();
      const res = await send('IMPORT_VAULT', { data: text, password: pw.input.value, scope });
      if (!res.ok) { err.replaceChildren(msgBox(res.error, 'error')); return; }
      close({ ok: true, count: res.count });
    }}, 'Import');
    const cancel = h('button', { class: 'btn secondary', onclick: () => close(null) }, 'Cancel');
    pw.input.addEventListener('keydown', (e) => { if (e.key === 'Enter') go.click(); });
    modal.appendChild(h('h3', {}, `Import ${label.toLowerCase()} backup`));
    modal.appendChild(h('p', { class: 'sub' }, `Replaces the current ${label.toLowerCase()} vault. Cannot be undone.`));
    modal.appendChild(h('div', { style: 'display:grid; gap:8px;' }, file, pw.wrap));
    modal.appendChild(err);
    modal.appendChild(h('div', { class: 'row', style: 'margin-top:12px;' }, go, cancel));
  });
  return result;
}

function renderBackupCard(state) {
  app.appendChild(h('h2', {}, 'Backup'));
  const card = h('div', { class: 'card' });
  const msg = h('div');

  function row(scope) {
    const label = scope === 'admin' ? 'Admin' : 'User';
    return h('div', { class: 'backup-row' },
      h('div', { class: 'backup-label' }, label),
      h('div', { class: 'backup-actions' },
        h('button', { class: 'btn sm secondary', onclick: async () => {
          const r = await openImportDialog(scope);
          if (!r) return;
          if (r.ok) { msg.replaceChildren(msgBox(`Imported ${r.count} ${label.toLowerCase()} entries`, 'success')); setTimeout(render, 800); }
        } }, 'Import'),
        h('button', { class: 'btn sm', onclick: async () => {
          const r = await doExport(scope);
          if (r.cancelled) return;
          msg.replaceChildren(r.ok ? msgBox(`${label} backup downloaded`, 'success') : msgBox(r.error, 'error'));
        } }, 'Export'),
      )
    );
  }

  card.appendChild(row('user'));
  if (state.adminInitialized) card.appendChild(row('admin'));
  card.appendChild(msg);
  return card;
}

// ---------- Change password (user + admin) ----------

function renderChangePasswordCard(state) {
  app.appendChild(h('h2', {}, 'Change password'));
  const card = h('div', { class: 'card' });
  const grid = h('div', { class: 'pw-change-grid' });
  grid.appendChild(changePasswordColumn('user'));
  if (state.adminInitialized) grid.appendChild(changePasswordColumn('admin'));
  card.appendChild(grid);
  return card;
}

function changePasswordColumn(scope) {
  const label = scope === 'admin' ? 'Admin' : 'User';
  const col = h('div', { class: 'pw-change-col' });
  col.appendChild(h('h3', {},
    h('span', { class: 'pill ' + (scope === 'admin' ? 'admin' : 'user') }, label),
    'Change ' + label.toLowerCase() + ' password'
  ));
  const cur = passwordWithEye({ placeholder: 'Current password' });
  const neu = passwordWithEye({ placeholder: 'New password (min 8)', autocomplete: 'new-password' });
  const conf = passwordWithEye({ placeholder: 'Confirm new password', autocomplete: 'new-password' });
  const msg = h('div');
  col.appendChild(cur.wrap);
  col.appendChild(neu.wrap);
  col.appendChild(conf.wrap);
  col.appendChild(h('button', { class: 'btn sm', onclick: async () => {
    if (!cur.input.value) { msg.replaceChildren(msgBox('Enter current password', 'error')); return; }
    if (neu.input.value.length < 8) { msg.replaceChildren(msgBox('New password must be at least 8 characters', 'error')); return; }
    if (neu.input.value !== conf.input.value) { msg.replaceChildren(msgBox('New passwords do not match', 'error')); return; }
    const res = await send('CHANGE_MASTER', { oldPassword: cur.input.value, newPassword: neu.input.value, scope });
    if (!res.ok) { msg.replaceChildren(msgBox(res.error, 'error')); return; }
    msg.replaceChildren(msgBox(`${label} password changed`, 'success'));
    cur.input.value = neu.input.value = conf.input.value = '';
  }}, 'Change'));
  col.appendChild(msg);
  return col;
}

// ---------- Danger zone (wipe requires BOTH passwords) ----------

function renderWipeCard(state) {
  app.appendChild(h('h2', {}, 'Danger zone'));
  const card = h('div', { class: 'card danger-card' });
  card.appendChild(h('div', { class: 'card-title' }, 'Wipe everything'));
  card.appendChild(h('p', { class: 'card-hint' },
    state.adminInitialized
      ? 'Deletes both vaults on this device. Requires BOTH the user and admin passwords. Cannot be undone.'
      : 'Deletes the vault on this device. Requires the user password. Cannot be undone.'));

  const userPw = passwordWithEye({ placeholder: 'User password' });
  const adminPw = state.adminInitialized ? passwordWithEye({ placeholder: 'Admin password' }) : null;
  const msg = h('div');
  card.appendChild(h('div', { class: 'form-row' }, h('label', {}, 'User password'), userPw.wrap));
  if (adminPw) card.appendChild(h('div', { class: 'form-row' }, h('label', {}, 'Admin password'), adminPw.wrap));
  card.appendChild(h('button', { class: 'btn danger', onclick: async () => {
    if (!userPw.input.value) { msg.replaceChildren(msgBox('User password required', 'error')); return; }
    if (adminPw && !adminPw.input.value) { msg.replaceChildren(msgBox('Admin password required', 'error')); return; }
    const confirmed = await confirmDelete();
    if (!confirmed) { msg.replaceChildren(msgBox('Cancelled', 'info')); return; }
    const payload = { userPassword: userPw.input.value };
    if (adminPw) payload.adminPassword = adminPw.input.value;
    const res = await send('WIPE_ALL', payload);
    msg.replaceChildren(res.ok ? msgBox('Wiped', 'success') : msgBox(res.error, 'error'));
    if (res.ok) setTimeout(render, 800);
  }}, 'Wipe everything'));
  card.appendChild(msg);
  return card;
}

render();
