const app = document.getElementById('app');
const LOGO_URL = chrome.runtime.getURL('icons/icon128.png');

// Per-popup UI state.
const uiState = {
  activeTab: 'user',        // which tab is currently showing
};

// ---------- messaging + DOM helpers ----------

function send(type, payload = {}) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type, ...payload }, (res) => resolve(res || { ok: false, error: 'No response' }));
  });
}

function h(tag, attrs = {}, ...children) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') el.className = v;
    else if (k === 'onclick') el.addEventListener('click', v);
    else if (k === 'onchange') el.addEventListener('change', v);
    else if (k === 'oninput') el.addEventListener('input', v);
    else if (k === 'onsubmit') el.addEventListener('submit', v);
    else if (k === 'onkeydown') el.addEventListener('keydown', v);
    else if (k === 'html') el.innerHTML = v;
    else if (v !== undefined && v !== null && v !== false) el.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    el.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
  }
  return el;
}

function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); }
function safeHost(url) { try { return new URL(url).hostname; } catch { return ''; } }
function faviconUrl(url) { const host = safeHost(url); if (!host) return null; return `https://www.google.com/s2/favicons?domain=${encodeURIComponent(host)}&sz=64`; }
function faviconEl(url, title) {
  const wrap = h('div', { class: 'entry-favicon' });
  const fav = faviconUrl(url);
  wrap.textContent = ((title || safeHost(url) || '?')[0] || '?').toUpperCase();
  if (fav) {
    const img = h('img', { src: fav, alt: '', loading: 'lazy' });
    img.addEventListener('error', () => img.remove());
    wrap.appendChild(img);
  }
  return wrap;
}

let currentTab = null;
async function getCurrentTab() {
  if (currentTab) return currentTab;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  currentTab = tab;
  return tab;
}

function hostsMatchLoose(a, b) {
  if (!a || !b) return false;
  a = a.toLowerCase(); b = b.toLowerCase();
  if (a === b) return true;
  return a.endsWith('.' + b) || b.endsWith('.' + a);
}

// ---------- inline icons ----------

const ICON_PATHS = {
  user: '<path d="M8 8a3 3 0 100-6 3 3 0 000 6zm0 1c-2.7 0-5 1.4-5 3.5V14h10v-1.5C13 10.4 10.7 9 8 9z"/>',
  key:  '<path d="M11 2a3 3 0 00-2.83 4H1v2h2v2h2V8h3.17A3 3 0 1011 2zm0 2a1 1 0 110 2 1 1 0 010-2z"/>',
  fill: '<path d="M7 1v8.6L4.4 7 3 8.4 8 13.4l5-5L11.6 7 9 9.6V1H7z"/><path d="M2 14h12v1.5H2z"/>',
};
function icon(name) {
  const wrap = document.createElement('span');
  wrap.setAttribute('aria-hidden', 'true');
  wrap.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" style="display:block;">${ICON_PATHS[name] || ''}</svg>`;
  return wrap.firstElementChild;
}

let toastEl = null;
function toast(msg) {
  if (toastEl) toastEl.remove();
  toastEl = h('div', { class: 'toast' }, msg);
  document.body.appendChild(toastEl);
  setTimeout(() => { if (toastEl) { toastEl.remove(); toastEl = null; } }, 1400);
}
async function copy(text) {
  if (!text) return;
  try { await navigator.clipboard.writeText(text); toast('Copied'); }
  catch { toast('Copy failed'); }
}

// ---------- styled modal (replaces window.prompt) ----------

function showModal(build) {
  return new Promise((resolve) => {
    const backdrop = h('div', { class: 'modal-backdrop' });
    let done = false;
    function close(value) { if (done) return; done = true; backdrop.remove(); resolve(value); }
    const modal = h('div', { class: 'modal' });
    build(modal, close);
    backdrop.appendChild(modal);
    backdrop.addEventListener('click', (e) => { if (e.target === backdrop) close(null); });
    document.body.appendChild(backdrop);
  });
}

function askPassword({ title, sub, confirmLabel = 'Continue', accent = 'user' }) {
  return showModal((modal, close) => {
    const pw = h('input', { type: 'password', placeholder: 'Password', autocomplete: 'off' });
    const btn = h('button', { class: 'btn', onclick: () => close(pw.value) }, confirmLabel);
    const cancel = h('button', { class: 'btn secondary', onclick: () => close(null) }, 'Cancel');
    pw.addEventListener('keydown', (e) => { if (e.key === 'Enter') close(pw.value); if (e.key === 'Escape') close(null); });
    modal.appendChild(h('h3', {}, h('span', { class: 'role-badge ' + accent }, accent === 'admin' ? 'Admin' : 'User'), ' ', title));
    if (sub) modal.appendChild(h('p', { class: 'sub' }, sub));
    modal.appendChild(pw);
    modal.appendChild(h('div', { class: 'row', style: 'margin-top:12px;' }, btn, cancel));
    setTimeout(() => pw.focus(), 40);
  });
}

// ---------- routing ----------

async function route() {
  const res = await send('CHECK_STATE');
  if (!res.ok) return renderError(res.error);
  if (!res.initialized) return renderSetup();
  if (!res.appUnlocked) return renderHomeLogin();
  return renderApp(res);
}

function renderError(msg) {
  clear(app);
  app.appendChild(h('div', { class: 'centered' },
    h('div', { class: 'brand-large', style: `background-image:url("${LOGO_URL}")` }),
    h('h2', {}, 'Error'),
    h('p', {}, msg || 'Unknown error')
  ));
}

// ---------- Setup ----------

function renderSetup() {
  clear(app);
  let error = '';
  const adminPw1 = h('input', { type: 'password', placeholder: 'Admin password (min 8)', autocomplete: 'new-password' });
  const adminPw2 = h('input', { type: 'password', placeholder: 'Confirm admin', autocomplete: 'new-password' });
  const userPw1 = h('input', { type: 'password', placeholder: 'User password (min 8)', autocomplete: 'new-password' });
  const userPw2 = h('input', { type: 'password', placeholder: 'Confirm user', autocomplete: 'new-password' });

  function submit() {
    error = '';
    if (adminPw1.value.length < 8 || userPw1.value.length < 8) { error = 'Both passwords must be at least 8 characters'; render(); return; }
    if (adminPw1.value !== adminPw2.value) { error = 'Admin passwords do not match'; render(); return; }
    if (userPw1.value !== userPw2.value) { error = 'User passwords do not match'; render(); return; }
    if (adminPw1.value === userPw1.value) { error = 'Admin and user passwords must differ'; render(); return; }
    btn.disabled = true;
    send('INITIALIZE', { adminPassword: adminPw1.value, userPassword: userPw1.value }).then((res) => {
      if (!res.ok) { error = res.error; btn.disabled = false; render(); return; }
      // Vaults created locked; user proceeds to the sign-in screen.
      route();
    });
  }
  const btn = h('button', { class: 'btn full', onclick: submit }, 'Create vaults');
  userPw2.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  const errBox = h('div');
  function render() { clear(errBox); if (error) errBox.appendChild(h('div', { class: 'msg error' }, error)); }

  app.appendChild(h('div', { class: 'centered' },
    h('div', { class: 'brand-large', style: `background-image:url("${LOGO_URL}")` }),
    h('h2', {}, 'Set up KeyNest'),
    h('p', {}, 'IT sets the admin password. The user sets the user password.'),
    h('div', { class: 'setup-section', style: 'width:100%;text-align:left;' },
      h('h3', {}, h('span', { class: 'pill admin' }, 'Admin')),
      h('div', { class: 'setup-columns' }, adminPw1, adminPw2),
    ),
    h('div', { class: 'setup-section', style: 'width:100%;text-align:left;' },
      h('h3', {}, h('span', { class: 'pill user' }, 'User')),
      h('div', { class: 'setup-columns' }, userPw1, userPw2),
    ),
    errBox, btn,
  ));
  render();
  setTimeout(() => adminPw1.focus(), 40);
}

// ---------- Home-screen login (either password) ----------

function renderHomeLogin() {
  clear(app);
  let error = '';
  const pwEl = h('input', { type: 'password', placeholder: 'Master password', autocomplete: 'off' });
  const btn = h('button', { class: 'btn full', onclick: submit }, 'Sign in');
  pwEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  const errBox = h('div');
  function renderErr() { clear(errBox); if (error) errBox.appendChild(h('div', { class: 'msg error' }, error)); }

  async function submit() {
    if (!pwEl.value) return;
    btn.disabled = true;
    const r = await send('APP_UNLOCK', { password: pwEl.value });
    if (r.ok) { route(); return; }
    error = r.error || 'Wrong password'; btn.disabled = false; renderErr(); pwEl.select();
  }

  app.appendChild(h('div', { class: 'centered' },
    h('div', { class: 'brand-large', style: `background-image:url("${LOGO_URL}")` }),
    h('h2', {}, 'KeyNest'),
    h('p', {}, 'Enter your password to open KeyNest.'),
    h('div', { class: 'form-group' }, pwEl),
    errBox, btn,
  ));
  renderErr();
  setTimeout(() => pwEl.focus(), 40);
}

// ---------- Main app (two tabs, each verified independently) ----------

async function renderApp(state) {
  clear(app);
  const tabInfo = await getCurrentTab();
  const currentHost = tabInfo?.url ? (() => { try { return new URL(tabInfo.url).hostname; } catch { return null; } })() : null;

  const header = h('div', { class: 'header' },
    h('div', { class: 'brand' },
      h('div', { class: 'logo', style: `background-image:url("${LOGO_URL}")` }),
      h('h1', {}, 'KeyNest'),
    ),
    h('div', { class: 'actions' },
      h('button', { class: 'icon-btn round', title: 'Add new login', onclick: () => openAddChooser(currentHost) }, '＋'),
      h('button', { class: 'icon-btn round', title: 'Settings', onclick: () => chrome.runtime.openOptionsPage() }, '⚙'),
      h('button', { class: 'icon-btn round', title: 'Sign out', onclick: async () => { await send('APP_LOCK'); route(); } }, '🔒'),
    )
  );

  const tabBar = h('div', { class: 'tab-bar' },
    h('button', {
      class: 'tab' + (uiState.activeTab === 'user' ? ' active' : ''),
      onclick: () => { uiState.activeTab = 'user'; route(); },
    }, h('span', { class: 'role-badge user' }, 'User')),
    h('button', {
      class: 'tab' + (uiState.activeTab === 'admin' ? ' active' : ''),
      onclick: () => { uiState.activeTab = 'admin'; route(); },
    }, h('span', { class: 'role-badge admin' }, 'Admin')),
  );

  const body = h('div', { class: 'content', style: 'padding:0;' });
  const scope = uiState.activeTab;
  const isUnlocked = scope === 'user' ? state.userUnlocked : state.adminUnlocked;
  if (!isUnlocked) {
    renderTabLockInto(body, scope);
  } else {
    await renderTabEntriesInto(body, scope, currentHost);
  }

  app.appendChild(header);
  app.appendChild(tabBar);
  app.appendChild(body);
}

function renderTabLockInto(container, scope) {
  let error = '';
  const pw = h('input', { type: 'password', placeholder: `${scope === 'admin' ? 'Admin' : 'User'} password`, autocomplete: 'off' });
  const btn = h('button', { class: 'btn', onclick: submit }, 'Verify');
  const errBox = h('div');
  pw.addEventListener('keydown', (e) => { if (e.key === 'Enter') submit(); });
  async function submit() {
    if (!pw.value) return;
    btn.disabled = true;
    const r = await send('UNLOCK', { password: pw.value, scope });
    if (!r.ok) { error = r.error || 'Wrong password'; btn.disabled = false; renderErr(); pw.select(); return; }
    route();
  }
  function renderErr() { clear(errBox); if (error) errBox.appendChild(h('div', { class: 'msg error' }, error)); }
  container.appendChild(h('div', { class: 'tab-lock' },
    h('div', { class: 'big' }, '🔐'),
    h('h3', {}, scope === 'admin' ? 'Admin tab' : 'User tab'),
    h('p', {}, `Enter the ${scope === 'admin' ? 'admin' : 'user'} password to view these logins.`),
    h('div', { class: 'row' }, pw, btn),
    errBox,
  ));
  setTimeout(() => pw.focus(), 40);
}

async function renderTabEntriesInto(container, scope, currentHost) {
  const listRes = scope === 'admin' ? await send('GET_ADMIN_ENTRIES') : await send('GET_ENTRIES');
  if (!listRes.ok) {
    container.appendChild(h('div', { class: 'empty' },
      h('div', { class: 'big' }, '⚠️'),
      h('div', {}, 'Could not read'),
      h('div', { class: 'subtle' }, listRes.error),
    ));
    return;
  }
  const entries = listRes.entries || [];

  let filter = '';
  const searchEl = h('input', { type: 'text', placeholder: 'Search…',
    oninput: (e) => { filter = e.target.value.toLowerCase(); paint(); } });
  const searchBox = h('div', { class: 'search-box' }, searchEl);
  const listBox = h('div', {});

  function matchSort(items) {
    let s = [...items];
    if (currentHost) {
      s.sort((a, b) => {
        const am = hostsMatchLoose(safeHost(a.url), currentHost) ? 0 : 1;
        const bm = hostsMatchLoose(safeHost(b.url), currentHost) ? 0 : 1;
        if (am !== bm) return am - bm;
        return (b.updatedAt || 0) - (a.updatedAt || 0);
      });
    } else {
      s.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
    }
    return s.filter((e) =>
      !filter ||
      (e.title || '').toLowerCase().includes(filter) ||
      (e.username || '').toLowerCase().includes(filter) ||
      (e.url || '').toLowerCase().includes(filter)
    );
  }
  function paint() {
    clear(listBox);
    const list = matchSort(entries);
    if (list.length === 0) {
      listBox.appendChild(h('div', { class: 'empty' },
        h('div', { class: 'big' }, entries.length === 0 ? '🗝️' : '🔍'),
        h('div', {}, entries.length === 0 ? 'No logins yet' : 'No matches'),
        entries.length === 0
          ? h('div', { class: 'subtle' }, 'Click ＋ to add one.')
          : h('div', { class: 'subtle' }, 'Try a different search.'),
      ));
      return;
    }
    const ul = h('ul', { class: 'entry-list' });
    for (const e of list) ul.appendChild(renderRow(e, currentHost, scope));
    listBox.appendChild(ul);
  }
  container.appendChild(searchBox);
  container.appendChild(listBox);
  paint();
}

function renderRow(e, currentHost, scope) {
  const isMatch = currentHost && hostsMatchLoose(safeHost(e.url), currentHost);
  const displayTitle = e.title || safeHost(e.url) || '(no title)';
  const titleRow = h('div', { class: 'entry-title' },
    isMatch ? h('span', { class: 'star' }, '★') : null,
    displayTitle
  );
  const actions = h('div', { class: 'entry-actions' },
    h('button', { class: 'icon-btn', title: 'Copy username', onclick: (ev) => { ev.stopPropagation(); copy(e.username); } }, icon('user')),
    h('button', { class: 'icon-btn', title: 'Copy password', onclick: (ev) => { ev.stopPropagation(); copy(e.password); } }, icon('key')),
    isMatch ? h('button', { class: 'icon-btn', title: 'Autofill on this page',
      onclick: (ev) => { ev.stopPropagation(); scope === 'admin' ? autofillManaged(e) : autofillUser(e); } }, icon('fill')) : null,
  );
  return h('li', { class: 'entry-item' + (scope === 'admin' ? ' managed' : ''), onclick: () => renderEditForm({ scope, existing: e, currentHost }) },
    faviconEl(e.url, displayTitle),
    h('div', { class: 'entry-body' },
      titleRow,
      h('div', { class: 'entry-username' }, e.username || '(no username)')
    ),
    actions
  );
}

async function autofillUser(entry) {
  const tab = await getCurrentTab();
  if (!tab?.id) return;
  try {
    await chrome.tabs.sendMessage(tab.id, { type: 'MV_AUTOFILL', username: entry.username, password: entry.password });
    toast('Filled'); window.close();
  } catch { toast('Cannot fill on this page'); }
}

async function autofillManaged(entry) {
  const tab = await getCurrentTab();
  if (!tab?.id) return;
  const res = await send('AUTOFILL_MANAGED', { id: entry.id, tabId: tab.id });
  if (res.ok) { toast('Filled'); window.close(); }
  else toast(res.error || 'Cannot fill on this page');
}

// ---------- Add flow: scope chooser → password → form ----------

async function openAddChooser(currentHost) {
  const scope = await showModal((modal, close) => {
    modal.appendChild(h('h3', {}, 'Save to which vault?'));
    modal.appendChild(h('p', { class: 'sub' }, 'Enter the matching password to save.'));
    modal.appendChild(h('div', { class: 'row' },
      h('button', { class: 'choice', 'data-scope': 'user', onclick: () => close('user') },
        h('span', { class: 'role-badge user' }, 'User'),
      ),
      h('button', { class: 'choice', 'data-scope': 'admin', onclick: () => close('admin') },
        h('span', { class: 'role-badge admin' }, 'Admin'),
      ),
    ));
    modal.appendChild(h('div', { class: 'cancel-row' },
      h('button', { class: 'btn secondary', onclick: () => close(null) }, 'Cancel'),
    ));
  });
  if (!scope) return;

  // ALWAYS verify the chosen scope's password before opening the form.
  while (true) {
    const pw = await askPassword({
      title: 'Verify',
      sub: `Enter the ${scope} password to add to the ${scope} vault.`,
      accent: scope,
      confirmLabel: 'Continue',
    });
    if (pw == null) return;
    const r = await send('UNLOCK', { password: pw, scope });
    if (r.ok) break;
    toast(r.error || 'Wrong password');
  }
  renderEditForm({ scope, existing: null, currentHost });
}

// ---------- Edit / Add form ----------

function renderEditForm({ scope, existing, currentHost }) {
  clear(app);
  const isEdit = !!existing;
  const s = scope;
  let error = '';

  const titleEl = h('input', { type: 'text', value: existing?.title || '', placeholder: 'e.g., GitHub' });
  const urlEl = h('input', { type: 'url', value: existing?.url || (currentHost ? 'https://' + currentHost : ''), placeholder: 'https://example.com' });
  const userEl = h('input', { type: 'text', value: existing?.username || '', placeholder: 'user@example.com' });
  const pwEl = h('input', { type: 'password', value: isEdit ? (existing.password || '') : '', placeholder: 'Password' });
  const notesEl = h('textarea', { placeholder: 'Notes (optional)' });
  notesEl.value = existing?.notes || '';
  const errBox = h('div');
  function renderErr() { clear(errBox); if (error) errBox.appendChild(h('div', { class: 'msg error' }, error)); }

  const toggle = h('button', { class: 'toggle', type: 'button', onclick: () => {
    pwEl.type = pwEl.type === 'password' ? 'text' : 'password';
    toggle.textContent = pwEl.type === 'password' ? 'show' : 'hide';
  }}, 'show');
  const pwWrap = h('div', {}, h('div', { class: 'password-field' }, pwEl, toggle));

  const genBtn = h('button', { class: 'chip-btn', type: 'button', onclick: async () => {
    const res = await send('GENERATE_PASSWORD', { options: { length: 20 } });
    if (!res.ok) return;
    pwEl.value = res.password;
    pwEl.type = 'text';
    toggle.textContent = 'hide';
  }}, '✨ Generate strong password');

  async function afterWrite() {
    // Immediate lock: clear vault session keys so tabs relock.
    await send('LOCK_VAULT_SESSIONS');
    uiState.activeTab = s;
    route();
  }

  async function save() {
    error = '';
    const entry = {
      title: titleEl.value.trim(),
      url: urlEl.value.trim(),
      username: userEl.value.trim(),
      password: pwEl.value,
      notes: notesEl.value,
    };
    if (!entry.password) { error = 'Password is required'; renderErr(); return; }
    if (!entry.url && !entry.title) { error = 'Set a title or URL'; renderErr(); return; }
    saveBtn.disabled = true;
    const res = isEdit
      ? await send('UPDATE_ENTRY', { id: existing.id, entry, scope: s })
      : await send('ADD_ENTRY', { entry, scope: s });
    if (!res.ok) { error = res.error; saveBtn.disabled = false; renderErr(); return; }
    afterWrite();
  }

  async function del() {
    if (!isEdit) return;
    if (!confirm('Delete this entry?')) return;
    const res = await send('DELETE_ENTRY', { id: existing.id, scope: s });
    if (!res.ok) { error = res.error; renderErr(); return; }
    afterWrite();
  }

  const saveBtn = h('button', { class: 'btn', onclick: save }, isEdit ? 'Save' : 'Add');

  const header = h('div', { class: 'header' },
    h('button', { class: 'icon-btn', onclick: () => route() }, '← Back'),
    h('div', { class: 'brand' },
      h('h1', {}, isEdit ? 'Edit' : 'Add'),
      h('span', { class: 'role-badge ' + s }, s === 'admin' ? 'Admin' : 'User'),
    ),
    h('div', {})
  );

  const content = h('div', { class: 'content' },
    h('div', { class: 'form-group' }, h('label', {}, 'Title'), titleEl),
    h('div', { class: 'form-group' }, h('label', {}, 'Website URL'), urlEl),
    h('div', { class: 'form-group' }, h('label', {}, 'Username / email'), userEl),
    h('div', { class: 'form-group' },
      h('label', {}, 'Password'),
      pwWrap,
      h('div', { class: 'pw-gen-row' }, genBtn)
    ),
    h('div', { class: 'form-group' }, h('label', {}, 'Notes'), notesEl),
    errBox,
  );

  const footer = h('div', { class: 'footer' },
    saveBtn,
    isEdit ? h('button', { class: 'btn danger', onclick: del }, 'Delete') : null,
    h('button', { class: 'btn secondary', onclick: () => route() }, 'Cancel')
  );

  app.appendChild(header);
  app.appendChild(content);
  app.appendChild(footer);
}

route();
